# autoocr
Wrapper for cross platform tesseract OCR engine with multiple languages (e.g. Bangla)
